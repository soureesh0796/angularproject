export class Menu{
    id: number;
    itemName: string;
    quantity: Number;
    price: number;
    image: string;
}