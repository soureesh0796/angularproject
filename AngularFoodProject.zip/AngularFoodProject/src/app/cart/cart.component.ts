import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Cart } from '../cart';
import { CartService } from '../cart.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cart: Cart[];
  totalCost: String;

  constructor(private router: Router, private cartService: CartService) { }

  ngOnInit() {
    this.cartService.listCart()
      .subscribe(data => {
        this.cart = data;
      });

    this.cartService.getTotalCost()
      .subscribe(data => {
        this.totalCost = data;
      });
  };

  proceedToPay() {
    this.cartService.proceedToPay()
      .subscribe(
      data => {
        console.log(data);
        this.ngOnInit();
      },
      error => console.log(error));
  }

}
